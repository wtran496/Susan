#ifndef ENEMY_HPP
#define ENEMY_HPP

#include "JSFML.hpp"
#include "Global.hpp"
#include "Bullets.hpp"
#include "GameProgression.hpp"

struct enemyStructure{
	double enemyX, enemyY;
	double enemyXDirection, enemyYDirection;
	double enemyStartX, enemyStartY;
	double enemyEndX, enemyEndY;
	bool dead;
	bool toStart;
	double sightDistance;
	double sightPulse;
	enemyStructure();
	enemyStructure(double startX, double startY, double endX, double endY, double speed, double distance, double startLocationPercentage);
};

//Load all images associated with the enemies
//~Run once when the program opens
void loadEnemy();

//Spawn the enemies for the specific level
void setupEnemy(int);

//Call every frame to draw the enemies
void updateEnemyMovement();


#endif