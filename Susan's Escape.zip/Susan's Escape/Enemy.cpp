#include "Enemy.hpp"

std::vector<enemyStructure> enemies(0);

void createEnemy(double startX, double startY, double endX, double endY, double movementSpeed, double radarDistance, double startLocationPercentage);

void lineOfSight(int);

enemyStructure::enemyStructure(){}

enemyStructure::enemyStructure(double startX, double startY, double endX, double endY, double speed, double distance, double startLocationPercentage){
	enemyX = startX+(endX-startX)*startLocationPercentage;
	enemyY = startY+(endY-startY)*startLocationPercentage;
	enemyStartX = startX;
	enemyStartY = startY;
	enemyEndX = endX;
	enemyEndY = endY;
	dead = false;
	toStart = false;
	sightDistance = distance;
	sightPulse = 20;
	double rad = (-atan2(enemyStartX - enemyEndX, enemyStartY - enemyEndY)) - (3.141592654 / 2);
	enemyXDirection = std::cos(rad);
	enemyYDirection = std::sin(rad);
	if (enemyStartX == enemyEndX)
		enemyXDirection = 0;
	if (enemyStartY == enemyEndY)
		enemyYDirection = 0;
	enemyXDirection *= speed;
	enemyYDirection *= speed;
}

void loadEnemy(){
	loadImage("Enemy", "assets/enemy.png");
}

void setupEnemy(int level)
{
	enemies.clear();
	sf::Image blueprint;
	if (levelTest)
		blueprint.loadFromFile("assets/level test/level "+std::to_string(level)+".png");
	else
		blueprint.loadFromFile("assets/blueprints/blueprint level "+std::to_string(level)+".png");
	struct enemySetup{
		int startX, startY;
		double viewDistance;
		double speed;
		sf::Color color;
		enemySetup(){}
		enemySetup(int x, int y, sf::Color c){
			startX = x;
			startY = y;
			color = c;
			viewDistance = c.r/255.0*170+30; //30-200
			if (c.r == 0)
				viewDistance = 0;
			speed = c.g/255.0*4+1;			 //1-5
		}
	};
	std::vector<enemySetup> eSetup(0);
	
	for (int y = 0; y < DISPLAY_HEIGHT/10; y++)
	{
		for (int x = 0; x < DISPLAY_WIDTH/10; x++)
		{
			sf::Color pixel = blueprint.getPixel(x, y);
			if (pixel != sf::Color(255, 0, 0) && pixel != sf::Color(0, 0, 255) && pixel != sf::Color(0, 255, 0) && pixel != sf::Color(255, 0, 255) && pixel != sf::Color(255, 255, 255))
			{
				bool existing = false;
				if (eSetup.size() > 0)
				{
					for (unsigned int i = 0; i < eSetup.size(); i++)
					{
						if (pixel == eSetup.at(i).color)
						{
							createEnemy(eSetup.at(i).startX, eSetup.at(i).startY, x*10, y*10, eSetup.at(i).speed, eSetup.at(i).viewDistance, eSetup.at(i).color.b/255.0);
							existing = true;
							eSetup.erase(eSetup.begin()+i);
							break;
						}
					}
				}
				if (!existing)
				{
					eSetup.push_back(enemySetup(x*10, y*10, pixel));
				}
			}
		}
	}
	if (eSetup.size() > 0)
	{
		for (unsigned int i = 0; i < eSetup.size(); i++)
		{
			createEnemy(eSetup.at(i).startX, eSetup.at(i).startY, eSetup.at(i).startX, eSetup.at(i).startY, 0, eSetup.at(i).viewDistance, eSetup.at(i).color.b/255.0);
		}
	}
}

void createEnemy(double startX, double startY, double endX, double endY, double speed, double distance, double location){
	enemies.push_back(enemyStructure(startX, startY, endX, endY, speed, distance, location));
}

void updateEnemyMovement()
{
	if (enemies.size() > 0)
	{
		for (unsigned int i = 0; i < enemies.size(); i++)
		{
			if (!enemies.at(i).dead)
			{
				if (!isMessageDisplayed())
				{
					enemies.at(i).enemyX += enemies.at(i).enemyXDirection;
					enemies.at(i).enemyY += enemies.at(i).enemyYDirection;
				}
				if (bulletHitEnemy(enemies.at(i).enemyX, enemies.at(i).enemyY))
				{
					enemies.at(i).dead = true;
				}
				lineOfSight(i);
				draw("Enemy", enemies.at(i).enemyX, enemies.at(i).enemyY);
				if ((distance(enemies.at(i).enemyX, enemies.at(i).enemyY, enemies.at(i).enemyEndX, enemies.at(i).enemyEndY) < 7 && !enemies.at(i).toStart) || (distance(enemies.at(i).enemyX, enemies.at(i).enemyY, enemies.at(i).enemyStartX, enemies.at(i).enemyStartY) < 7 && enemies.at(i).toStart))
				{
					enemies.at(i).enemyXDirection *= -1;
					enemies.at(i).enemyYDirection *= -1;
					enemies.at(i).toStart = !enemies.at(i).toStart;
				}
			}
		}
	}
}

void lineOfSight(int i)
{
	if (!isMessageDisplayed())
	{
		if (enemies.at(i).sightPulse < enemies.at(i).sightDistance)
			enemies.at(i).sightPulse += 2;
		else
			enemies.at(i).sightPulse = 20;
	}

	if (distance(enemies.at(i).enemyX, enemies.at(i).enemyY, playerX, playerY) <= enemies.at(i).sightPulse+22)
		setLevelFailed();
	if (enemies.at(i).sightDistance > 0)
	{
		sf::CircleShape enemySight(enemies.at(i).sightPulse, enemies.at(i).sightPulse*3);
		enemySight.setPosition(enemies.at(i).enemyX, enemies.at(i).enemyY);
		enemySight.setOrigin(enemies.at(i).sightPulse, enemies.at(i).sightPulse);
		sf::Color transparent(0, 0, 0, 0);
		sf::Color outline(220, 0, 0, 180);
		enemySight.setOutlineColor(outline);
		enemySight.setFillColor(transparent);
		enemySight.setOutlineThickness(3);
		window.draw(enemySight);
	}
}