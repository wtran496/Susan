//Jason O'Neill

#include "Global.hpp"

//Game/Menu States
bool mainMenuShow;
bool gameShow;
int currentLevel;
int maxLevel;

//Player Location
double playerX;
double playerY;

//Debug to experiment with new level designs
bool levelTest = true;

void loadGlobal(){
	mainMenuShow = true;
	gameShow = false;
}