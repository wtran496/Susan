#ifndef MAINMENU_HPP
#define MAINMENU_HPP

#include "JSFML.hpp"
#include "Global.hpp"
#include "GameProgression.hpp"

//Load all images associated with the menu
//~Run once when the program opens
void loadMainMenu();

//Call every frame to draw the menu
void drawMainMenu();

//Called when the mouse is pressed in the menu
void mainMenuClick();


#endif //MAINMENU_HPP