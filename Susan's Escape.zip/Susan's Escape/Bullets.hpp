#ifndef BULLETS_HPP
#define BULLETS_HPP

#include "JSFML.hpp"
#include "Global.hpp"
#include "Collision.hpp"
#include "GameProgression.hpp"

//Load all images associated with the bullets
//~Run once when the program opens
void loadBullets();

//Call every frame to draw the bullets
void drawBullets();

//Setup weapon properties for the given level
void setupBullets(int level);

//Called when the mouse is clicked to handle the bulllet shooting
void bulletHandler();
struct bulletStructure{
	double moveX;
	double moveY;
	double bulletX;
	double bulletY;
	double bulletOrientation;
	double bulletDistance;
	bulletStructure();
	bulletStructure(double moveX, double moveY, double bulletX, double bulletY, double bulletOrientation);
};
//Called from enemy to determine if there is a bullet within 25px radius of it
bool bulletHitEnemy(int x, int y);

#endif //BULLETS_HPP