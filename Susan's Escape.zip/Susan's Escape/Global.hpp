#ifndef GLOBAL_HPP
#define GLOBAL_HPP

//Game/Menu States
extern bool mainMenuShow;
extern bool gameShow;
extern int currentLevel;
extern int maxLevel;

//Player Location
extern double playerX;
extern double playerY;

//Debug to experiment with new level designs
extern bool levelTest;

//Loads all global variables
//~Run once when the program opens
void loadGlobal();

#endif //GLOBAL_HPP