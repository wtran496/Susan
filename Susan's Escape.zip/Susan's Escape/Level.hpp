//Jason O'Neill

#ifndef LEVEL_HPP
#define LEVEL_HPP

#include "JSFML.hpp"
#include "Global.hpp"
#include "GameProgression.hpp"

extern std::vector<box> walls;

//Load all images associated with the levels
//~Run once when the program opens
void loadLevels();

//Scan the blueprint and create that specific level
void setupLevel(int level);

//Call each frame directly BEFORE the player is drawn
void drawLevel();

//Call each frame directly AFTER the player is drawn
void drawWalls();

#endif //LEVEL_HPP