#include "Bullets.hpp"

int bulletCount;
int bulletSpeed;
int bulletMaxDistance;
int bulletDelay;
int lastShot;


//Declare variables
//Structure and vector
bulletStructure::bulletStructure(){};
bulletStructure::bulletStructure(double moveX, double moveY, double bulletX, double bulletY, double bulletOrientation)
{
	this->moveX = moveX;
	(*this).moveY = moveY;
	this->bulletX = bulletX;
	this->bulletY = bulletY;
	this->bulletOrientation = bulletOrientation;
	bulletDistance = 0;
}
std::vector<bulletStructure> bulletVector(0);

void loadBullets(){
	loadImage("slimeball", "assets/slimeball.png");
}


void setupBullets(int level)
{
	bulletVector.clear();
	//(1000 milliseconds in 1 second)
	//if (level == 1){
		bulletDelay = 550;
		bulletSpeed = 15;
		bulletMaxDistance = 2000;
	//}

	lastShot = getTime();
	

}

void drawBullets()
{
	if (bulletVector.size() > 0)
	{
		int destroy = -1;
		for (unsigned int i = 0; i < bulletVector.size(); i++)
		{
			for (int k = 0; k < bulletSpeed; k++)
			{
				if (!isMessageDisplayed())
				{
					bulletVector.at(i).bulletX += bulletVector.at(i).moveX;
					bulletVector.at(i).bulletY += bulletVector.at(i).moveY;
					bulletVector.at(i).bulletDistance += 2;
				}
				if (bulletVector.at(i).bulletDistance > bulletMaxDistance)
				{
					destroy = i;
					break;
				}
				int wallDirection = bulletBounce(bulletVector.at(i).bulletX, bulletVector.at(i).bulletY);

				if (wallDirection == 1 && bulletVector.at(i).moveY < 0) //up
				{
					bulletVector.at(i).moveY *= -1;
					if (bulletVector.at(i).moveX >= 0)
						bulletVector.at(i).bulletOrientation = atan(bulletVector.at(i).moveY/bulletVector.at(i).moveX)*180/3.141592654 + 90;
					else
						bulletVector.at(i).bulletOrientation = atan(bulletVector.at(i).moveY/bulletVector.at(i).moveX)*180/3.141592654 - 90;
				}
				if (wallDirection == 2 && bulletVector.at(i).moveX > 0) //right
				{
					bulletVector.at(i).moveX *= -1;
					bulletVector.at(i).bulletOrientation = atan(bulletVector.at(i).moveY/bulletVector.at(i).moveX)*180/3.141592654 - 90;
				}
				if (wallDirection == 3 && bulletVector.at(i).moveY > 0) //down
				{
					bulletVector.at(i).moveY *= -1;
					if (bulletVector.at(i).moveX >= 0)
						bulletVector.at(i).bulletOrientation = atan(bulletVector.at(i).moveY/bulletVector.at(i).moveX)*180/3.141592654 + 90;
					else
						bulletVector.at(i).bulletOrientation = atan(bulletVector.at(i).moveY/bulletVector.at(i).moveX)*180/3.141592654 - 90;
				}
				if (wallDirection == 4 && bulletVector.at(i).moveX < 0) //left
				{
					bulletVector.at(i).moveX *= -1;
					bulletVector.at(i).bulletOrientation = atan(bulletVector.at(i).moveY/bulletVector.at(i).moveX)*180/3.141592654 + 90;
				}
			}
			setRotation("slimeball", bulletVector.at(i).bulletOrientation);
			draw("slimeball", bulletVector.at(i).bulletX, bulletVector.at(i).bulletY);
		}
		if (destroy != -1)
			bulletVector.erase(bulletVector.begin()+destroy);
	}
}

void bulletHandler()
{
	//Allows for delay in bullets
	if (getTime() - lastShot > bulletDelay)
	{
		//Resets timer for lastShot
		lastShot = getTime();
		double bulletX = playerX;
		double bulletY = playerY;
		double bullet_radians = (-atan2(playerX - mouse.x, playerY - mouse.y)) - (3.141592654 / 2);
		double moveX = std::cos(bullet_radians) * 2;
		double moveY = std::sin(bullet_radians) * 2;
		double bulletOrientation = bullet_radians * 180 / 3.141592654 +90;
		bulletStructure b(moveX, moveY, bulletX, bulletY, bulletOrientation);
		bulletVector.push_back(b);
	}
}

bool bulletHitEnemy(int x, int y){
	if (bulletVector.size() > 0)
	{
		for (unsigned int i = 0; i < bulletVector.size(); i++)
		{
			if (distance(bulletVector.at(i).bulletX, bulletVector.at(i).bulletY, x, y) <= 28)
			{
				bulletVector.at(i).bulletDistance = bulletMaxDistance+5;
				return true;
			}
		}
	}
	return false;
}