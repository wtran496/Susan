#include "Level.hpp"

std::vector<box> walls(0);

int portalX, portalY;

void loadLevels(){
	loadImage("portal", "assets/portal.png");
	if (!levelTest)
	{
		for (int i = 1; i < 2; i++)
		{
			loadImage("level "+std::to_string(i), "assets/levels/level "+std::to_string(i)+".png");
			loadImage("level walls "+std::to_string(i), "assets/levels/level walls "+std::to_string(i)+".png");
		}
	}
	else
	{
		maxLevel = 1;
		sf::Image loadTest;
		while (loadTest.loadFromFile("assets/level test/level "+std::to_string(maxLevel)+".png"))
		{
			maxLevel++;
		}
		println("Don't worry: That Error above was expected.");
		maxLevel--;
	}
}

void setupLevel(int level){
	walls.clear();
	sf::Image blueprint;
	if (levelTest)
		blueprint.loadFromFile("assets/level test/level "+std::to_string(level)+".png");
	else
		blueprint.loadFromFile("assets/blueprints/blueprint level "+std::to_string(level)+".png");
	for (int x = 0; x < DISPLAY_WIDTH/10; x++)
	{
		int wallHeight = 0;
		for (int y = 0; y < DISPLAY_HEIGHT/10; y++)
		{
			if (blueprint.getPixel(x, y) == sf::Color(255, 0, 0)) //Vertical Walls - red
				wallHeight++;
			else if (wallHeight > 0)
			{
				box b(x*10+5, y*10-wallHeight*10/2, 10, wallHeight*10);
				walls.push_back(b);
				wallHeight = 0;
			}
		}
		if (wallHeight > 0)
		{
			box b(x*10+5, DISPLAY_HEIGHT-wallHeight*10/2, 10, wallHeight*10);
			walls.push_back(b);
		}
	}
	for (int y = 0; y < DISPLAY_HEIGHT/10; y++)
	{
		int wallWidth = 0;
		for (int x = 0; x < DISPLAY_WIDTH/10; x++)
		{
			if (blueprint.getPixel(x, y) == sf::Color(0, 0, 255)) // Horizontal walls - blue
				wallWidth++;
			else if (wallWidth > 0)
			{
				box b(x*10-wallWidth*10/2, y*10+5, wallWidth*10, 10);
				walls.push_back(b);
				wallWidth = 0;
			}
		}
		if (wallWidth > 0)
		{
			box b(DISPLAY_WIDTH-wallWidth*10/2, y*10+5, wallWidth*10, 10);
			walls.push_back(b);
		}
	}
	for (int x = 0; x < DISPLAY_WIDTH/10; x++)
	{
		for (int y = 0; y < DISPLAY_HEIGHT/10; y++)
		{
			if (blueprint.getPixel(x, y) == sf::Color(0, 255, 0)) // Player Start - green
			{
				playerX = x*10;
				playerY = y*10;
			}
			if (blueprint.getPixel(x, y) == sf::Color(255, 0, 255)) // Player End (portal) - purple
			{
				portalX = x*10;
				portalY = y*10;
			}
		}
	}
}

void drawLevel(){
	if (!levelTest)
		draw("level "+std::to_string(currentLevel), DISPLAY_WIDTH/2, DISPLAY_HEIGHT/2);
	draw("portal", portalX, portalY);
	if (distance(portalX, portalY, playerX, playerY) < 15)
	{
		setLevelComplete();
	}
}

void drawWalls(){
	if (levelTest)
	{
		rectColor(0, 0, 0);
		for (unsigned int i = 0; i < walls.size(); i++)
		{
			box b(walls.at(i).xPos, walls.at(i).yPos, walls.at(i).xSize, walls.at(i).ySize);
			rect(b);
		}
	}
	else
		draw("level walls "+std::to_string(currentLevel), DISPLAY_WIDTH/2, DISPLAY_HEIGHT/2);
}