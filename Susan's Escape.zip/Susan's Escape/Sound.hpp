#ifndef SOUND_HPP
#define SOUND_HPP

#include "JSFML.hpp"
#include "SFML/Audio.hpp"

void loadSound(std::string name, std::string fileName);
bool playSound(std::string name, bool forcePlay = false);
void stopSound(std::string name);
void pauseSound(std::string name);
void setLoop(std::string name, bool loop);
void setPitch(std::string name, double pitch);

#endif //SOUND_HPP