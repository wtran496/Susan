#ifndef JSFML_HPP
#define JSFML_HPP

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Network.hpp>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
#include <random>
#include <chrono>
#include <map>
#include <memory>
#include <thread>

#define DISPLAY_WIDTH 900
#define DISPLAY_HEIGHT 700
#define WINDOW_NAME "Susan's Escape"

#define CENTER 1
#define LEFT 2
#define RIGHT 3

extern int keyCode;
extern bool closing;
extern sf::RenderWindow window;

//Set window icon
void setIcon(std::string path);

//Debugging

template<class ptln>
void println(ptln stuff){
	std::cout << stuff << std::endl;
}

template<class pt>
void print(pt stuff){
	std::cout << stuff;
}

//Fills the entire screen with this color
void background(int red, int green, int blue, int alpha = 255);

//Fills the entire screen with this color - greyscale
void background(int grey, int alpha = 255);

//Sets the color that any following rectangles will be filled with
//The color is saved until it is changed by this function again
void rectColor(int red, int green, int blue, int alpha = 255);

//This datatype is used to draw rectangles, detect mouseovers, etc
struct box{
	int xPos;
	int yPos;
	float xSize;
	float ySize;
	box();
	box(int x, int y, float xSize, float ySize);
};
//Draws a line around a rectangle shape
//The color of the outline is set with rectColor()
void rectOutline(box);
//Draws a rectangle
//The color of the shape is set with rectColor()
void rect(box);

//Returns the distance between two points
int distance(int x1, int y1, int x2, int y2);

//Called every time the left or right mouse button is clicked
void clickHandler();

struct mouseVariables{
	bool left;
	bool right;
	int x;
	int y;
	bool down;
	bool outside;

	mouseVariables();

	void printLocation();
};

extern mouseVariables mouse;

void mousePressedHandler();

//Returns true if the cursor is inside the box
bool mouseover(box);


//TextDraw
extern sf::Font defaultFont;

//Creates an object which holds text to be drawn
class textDisplay{
private:
	sf::Text displayText;
	int textAlign;
public:
	//Initialize the text to a string
	textDisplay(std::string text= "");
	//Set the text to a string
	void setText(std::string text);
	//Set the text color
	void setColor(int red, int green, int blue, int alpha = 255);
	//Set the text color - greyscale
	void setColor(int grey, int alpha = 255);
	//Set the text size
	void setSize(int size);
	//Set the text font
	//Must make the sf::Font variable global and keep it in memory
	void setFont(sf::Font& font);
	//Returns the width in pixels of the text at the current size with the current font
	int getTextWidth();
	//Sets the justification of the text (LEFT, RIGHT, CENTER)
	void align(int alignment);
	//Displays the text on screen
	void draw(int x, int y);
};


//Image Draw
class Image{
private:
	sf::Sprite image;
	sf::Color imageTint;
public:

	Image(std::unique_ptr<sf::Texture> const&);
	//Apply a color filter over the image
	void tint(int red, int green, int blue);
	//Apply a color filter over the image - and make it transparent
	void tint(int red, int green, int blue, int alpha);
	//Apply a color filter over the image - greyscale
	void tint(int grey);
	//Apply a color filter over the image - greyscale - and make it transparent
	void tint(int grey, int alpha);
	//Scales the size of the image
	void setScale(double scale);
	//Rotates the image (degrees)
	void setRotation(double degrees);
	//Displays the image
	void draw(double x, double y);

};

extern std::map<std::string, std::unique_ptr<Image>> images;

extern std::map<std::string, std::unique_ptr<sf::Texture>> textures;
//Load an image permanently into memory
void loadImage(std::string referenceName, std::string filePath);
//Apply a color filter over the image
void tint(std::string imageName, int red, int green, int blue);
//Apply a color filter over the image - and make it transparent
void tint(std::string imageName, int red, int green, int blue, int alpha);
//Apply a color filter over the image - and make it transparent
void tint(std::string imageName, int grey);
//Apply a color filter over the image - greyscale - and make it transparent
void tint(std::string imageName, int grey, int alpha);
//Scales the size of the image
void setScale(std::string imageName, double scale);
//Rotates the image (degrees)
void setRotation(std::string imageName, double degrees);
//Displays the image
void draw(std::string imageName, double x, double y);

//Returns the milliseconds since the program opened
int getTime();

//Returns a random integer between two numbers
int random(int low, int high);
//Returns a random integer between 0-number
int random(int high);

#endif //JSFML_HPP