#ifndef GAMEPROGRESSION_HPP
#define GAMEPROGRESSION_HPP

#include "JSFML.hpp"
#include "Global.hpp"
#include "Movement.hpp"
#include "Level.hpp"
#include "Enemy.hpp"
#include "Bullets.hpp"

//Returns true if any message is on the screen
bool isMessageDisplayed();

//Call LAST every frame
void drawLevelText();

//Sets the Level Complete Text to display
void setLevelComplete();

//Sets the Level Failed text to display and automatically reset the level in 2 seconds
void setLevelFailed();

//Called at the beginning of each level or when a level resets
void setupLevelAll(int level);

//Checks for level specific key presses
void gameProgressionKeyPress();

#endif //GAMEPROGRESSION_HPP