#include "MainMenu.hpp"

void loadMainMenu(){
	loadImage("title", "assets/title.png");
	loadImage("main menu background", "assets/main menu background.png");
}

void drawMainMenu(){
	draw("main menu background", DISPLAY_WIDTH/2, DISPLAY_HEIGHT/2);
	draw("title", DISPLAY_WIDTH/2, DISPLAY_HEIGHT/2);
	box playButton(700, 500, 300, 45);
	rectColor(25, 25, 200);
	if (mouseover(playButton))
		rectOutline(playButton);
	textDisplay play("Begin your Adventure");
	play.setSize(28);
	play.setColor(255);
	play.draw(700, 480);
}

void mainMenuClick(){
	box playButton(700, 500, 300, 45);
	if (mouseover(playButton))
	{
		mainMenuShow = false;
		gameShow = true;
		currentLevel = 1;
		setupLevelAll(currentLevel);
	}
}