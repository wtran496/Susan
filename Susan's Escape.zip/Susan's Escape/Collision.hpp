#ifndef COLLISION_HPP
#define COLLISION_HPP

#include "JSFML.hpp"
#include "Level.hpp"

//If the player is smaller than 50x50 then use the second two arguments
bool playerCollision(int x, int y, int xSize = 45, int ySize = 45);

//Returns 0-4 depending on which side of the bullet hit a wall
//0 = didn't hit anything
//1 = top
//2 = right
//3 = bottom
//4 = left
int bulletBounce(int x, int y);

#endif //COLLISION_HPP