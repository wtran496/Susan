#ifndef MOVEMENT_HPP
#define MOVEMENT_HPP

#include "JSFML.hpp"
#include "Collision.hpp"
#include "Global.hpp"
#include "GameProgression.hpp"

//Load all images associated with the enemies
//~Run once when the program opens
void loadPlayer();

//Spawn the player at x and y
void setupPlayer(int x, int y);

//Call every frame to draw the player
void drawPlayer();

//Called when key pressed
void movementKeyPressed();

//Called when key relasee
void movementKeyReleased();

#endif //MOVEMENT_HPP