#include "GameProgression.hpp"

bool levelComplete;
bool levelFailed;
int textDisplayTime;

void setupLevelText(){
	levelComplete = false;
	levelFailed = false;
	textDisplayTime = -10000;
}

void setLevelComplete(){
	if (!levelComplete)
	{
		levelComplete = true;
		textDisplayTime = getTime();
	}
}

void setLevelFailed(){
	if (!levelFailed)
	{
		levelFailed = true;
		textDisplayTime = getTime();
	}
}

bool isMessageDisplayed(){
	if (levelComplete || levelFailed)
		return true;
	return false;
}

void drawLevelText(){
	if (levelComplete)
	{
		background(0, 150);
		textDisplay complete("Level "+std::to_string(currentLevel)+" Complete");
		complete.setColor(0, 255, 0);
		complete.setSize(40);
		complete.draw(DISPLAY_WIDTH/2, 320);
		if (currentLevel < maxLevel)
			complete.setText("Press Enter to move on to the next level.");
		else
			complete.setText("Press Enter to return to the Main Menu.");
		complete.setColor(200, 200, 200);
		complete.setSize(20);
		complete.draw(DISPLAY_WIDTH/2, 375);
	}
	if (levelFailed)
	{
		background(0, 150);
		textDisplay failed("You have been spotted!");
		failed.setSize(35);
		failed.setColor(255, 0, 0);
		failed.draw(DISPLAY_WIDTH/2, 325);
		failed.setSize(30);
		failed.align(LEFT);
		if (getTime() - textDisplayTime < 500)
			failed.setText("Resetting");
		else if (getTime() - textDisplayTime < 1000)
			failed.setText("Resetting.");
		else if (getTime() - textDisplayTime < 1500)
			failed.setText("Resetting..");
		else
			failed.setText("Resetting...");
		failed.draw(DISPLAY_WIDTH/2-80, 370);
		if (getTime() - textDisplayTime > 2000)
		{
			setupLevelAll(currentLevel);
		}
	}
}

void setupLevelAll(int level){
	setupLevelText();
	setupLevel(level);
	setupEnemy(level);
	setupBullets(level);
}

void gameProgressionKeyPress(){
	if (keyCode == 10 || keyCode == 13) //Enter
	{
		if (currentLevel < maxLevel)
		{
			currentLevel++;
			setupLevelAll(currentLevel);
		}
		else
		{
			mainMenuShow = true;
			gameShow = false;
		}
	}
}