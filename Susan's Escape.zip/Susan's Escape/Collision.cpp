#include "Collision.hpp"


bool playerCollision(int x, int y, int width, int height){
	if (x-width/2 <= 0 || x+width/2 >= DISPLAY_WIDTH)
		return false;
	if (y-height/2 <= 0 || y+height/2 >= DISPLAY_HEIGHT)
		return false;
	for (unsigned int i = 0; i < walls.size(); i++)
	{
		sf::FloatRect r(walls.at(i).xPos-walls.at(i).xSize/2, walls.at(i).yPos-walls.at(i).ySize/2, walls.at(i).xSize, walls.at(i).ySize);
		if (r.contains(x-width/2+3, y) || r.contains(x+width/2-3, y) || r.contains(x, y-height/2+3) || r.contains(x, y+height/2-3))
			return true;
		if (r.contains(x-width/2+3, y-height/2+3) || r.contains(x+width/2-3, y-height/2+3) || r.contains(x-width/2+3, y-height/2+3) || r.contains(x+width/2-3, y+height/2-3))
			return true;
		if (r.contains(x-width/4, y-height/2+3) || r.contains(x+width/4, y-height/2+3) || r.contains(x-width/2+3, y-height/4) || r.contains(x-width/2+3, y+height/4))
			return true;
		if (r.contains(x-width/4, y+height/2+3) || r.contains(x+width/4, y+height/2+3) || r.contains(x+width/2+3, y-height/4) || r.contains(x+width/2+3, y+height/4))
			return true;
	}
	return false;
}

int bulletBounce(int x, int y){
	for (unsigned int i = 0; i < walls.size(); i++)
	{ 
		sf::FloatRect r(walls.at(i).xPos-walls.at(i).xSize/2, walls.at(i).yPos-walls.at(i).ySize/2, walls.at(i).xSize, walls.at(i).ySize);
		if (r.contains(x, y-5))
			return 1;
		else if (r.contains(x+5, y))
			return 2;
		else if (r.contains(x, y+5))
			return 3;
		else if (r.contains(x-5, y))
			return 4;
	}
	return 0;
}