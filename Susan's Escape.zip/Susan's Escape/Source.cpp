#include "JSFML.hpp"
#include "MainMenu.hpp"
#include "Collision.hpp"
#include "Global.hpp"
#include "Movement.hpp"
#include "Level.hpp"
#include "Enemy.hpp"
#include "Bullets.hpp"
#include "GameProgression.hpp"
#include "Sound.hpp"

//Functions
void gameLoop();
void keyPress();

//Millis Timers
int gameMillis = 0;

int main()
{ 

	//Once when the program starts
	loadMainMenu();
	loadGlobal();
	loadLevels();
	loadEnemy();
	loadBullets();
	loadPlayer();

	window.setFramerateLimit(30);
	setIcon("assets/icon.png");
	defaultFont.loadFromFile("assets/arial.ttf");
	std::thread(mousePressedHandler).detach();
	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
			{
				closing = true;
				window.close();
			}
			if (event.type == sf::Event::TextEntered)
			{
				keyCode = event.key.code;
				keyPress();
			}
			if (event.type == sf::Event::KeyPressed)
			{
				movementKeyPressed();
			}
			if (event.type == sf::Event::KeyReleased)
			{
				movementKeyReleased();
			}
		}
		if (!window.hasFocus())
		{
			
		}
		if (getTime()-gameMillis >= 33)
		{
			if (getTime()-gameMillis > 1000)
				gameMillis = getTime();
			while (getTime()-gameMillis >= 33)
			{
				gameMillis += 34;
				gameLoop();
			}
			window.display();
		}
	}
	return 0;
}

void gameLoop(){
	background(255);
	if (gameShow)
	{
		drawLevel();
		drawPlayer();
		drawWalls();
		updateEnemyMovement();
		drawBullets();
		drawLevelText();
	}
	else
	{
		drawMainMenu();
	}
	
}

void clickHandler(){
	if (mainMenuShow)
	{
		mainMenuClick();
	}
	else if (gameShow)
	{
		bulletHandler();
	}
}

void keyPress(){
	gameProgressionKeyPress();
}