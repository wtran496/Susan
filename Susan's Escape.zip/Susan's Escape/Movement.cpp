#include "Movement.hpp"

bool keepMovingA, keepMovingS, keepMovingD, keepMovingW;
double accelW, accelA, accelS, accelD;
double maxSpeed = 0.46;
void movement();

void loadPlayer(){
	loadImage("Player", "assets/player.png");
}

void setupPlayer(int x, int y){
	//rounded by giving +.5 if it needed to round up or else it will be rounded down
	playerX = int((x + .5));
	playerY = int((y + .5));
}

void drawPlayer(){
	if (!isMessageDisplayed())
	{
		movement();
		setRotation("Player", -atan2(playerX - mouse.x, playerY - mouse.y)*(180 / 3.14159265359));
	}
	draw("Player", playerX, playerY);
}

void movement(){
	//variables stay in this function, not outside because it doesn't reset to 0
	if ((keepMovingA && keepMovingS) || (keepMovingA && keepMovingW) || (keepMovingD && keepMovingS) || (keepMovingD && keepMovingW))
	{// 4.243/6 = 0.707166666666667 for the for loops use for accel add then divide
		if (keepMovingA && keepMovingS)
		{
			for (int xy = 1; xy <= 6; xy++)
			{
				if (playerCollision(playerX - 6, playerY) || (playerCollision(playerX, playerY + 6))){
					if (playerCollision(playerX, playerY + 6)){
						if (!playerCollision(playerX - 6, playerY))
							playerX -= ((4.243 / 6) + accelA); // slide left
					}
					else // slide downwards
						playerY += ((4.243 / 6) + accelS);
				}
				else{ // no walls around
					playerX -= ((4.243 / 6) + accelA);
					playerY += ((4.243 / 6) + accelS);
				}
			}
		}
		if (keepMovingA && keepMovingW)
		{
			for (int xy = 1; xy <= 6; xy++)
			{	
				if (playerCollision(playerX - 6, playerY) || (playerCollision(playerX, playerY - 6))){
					if (playerCollision(playerX, playerY - 6)){
						if (!playerCollision(playerX - 6, playerY))
							playerX -= ((4.243 / 6) + accelA); // slide left
					}
					else // slide upwards
						playerY -= ((4.243 / 6) + accelW);
				}
				else{ // no walls around
					playerX -= ((4.243 / 6) + accelA);
					playerY -= ((4.243 / 6) + accelW);
				}
			}
		}
		if (keepMovingD && keepMovingS)
		{
			for (int xy = 1; xy <= 6; xy++)
			{
				if (playerCollision(playerX + 6, playerY) || (playerCollision(playerX, playerY + 6))){
					if (playerCollision(playerX, playerY + 6)){
						if (!playerCollision(playerX + 6, playerY))
							playerX += ((4.243 / 6) + accelD); // slide right
					}
					else // slide downwards
						playerY += ((4.243 / 6) + accelS);
				}
				else{ // no walls around
					playerX += ((4.243 / 6) + accelD);
					playerY += ((4.243 / 6) + accelS);
				}
			}
		}
		if (keepMovingD && keepMovingW)
		{
			for (int xy = 1; xy <= 6; xy++)
			{
				if (playerCollision(playerX + 6, playerY) || (playerCollision(playerX, playerY - 6))){
					if (playerCollision(playerX, playerY - 6)){
						if (!playerCollision(playerX + 6, playerY))
							playerX += ((4.243 / 6) + accelD); // slide right
					}
					else // slide upwards
						playerY -= ((4.243 / 6) + accelW);
				}
				else{ // no walls around
					playerX += ((4.243 / 6) + accelD);
					playerY -= ((4.243 / 6) + accelW);
				}
			}
		}
	}
	else{//check each pixel, if that pixel collides then break out of for loop
		if (keepMovingA)
		{
			for (int x = 1; x <= 6; x++)
			{
				if (playerCollision(playerX - 6, playerY))
					break;
				playerX -= (1 + accelA);
			}
		}
		if (keepMovingS)
		{
			for (int y = 1; y <= 6; y++)
			{
				if (playerCollision(playerX, playerY + 6))
					break;
				playerY += (1 + accelS);
			}
		}
		if (keepMovingD)
		{
			for (int x = 1; x <= 6; x++)
			{
				if (playerCollision(playerX + 6, playerY))
					break;
				playerX += (1 + accelD);
			}
		}
		if (keepMovingW)
		{
			for (int y = 1; y <= 6; y++)
			{
				if (playerCollision(playerX, playerY - 6))
					break;
				playerY -= (1 + accelW);
			}
		}
	}
}
void movementKeyPressed(){
	//if a key is pressed then is true
	//make a release function to false
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::D)){
		keepMovingD = true;
		accelD += .02;
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::A)){
		keepMovingA = true;
		accelA += .02;
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)){
		keepMovingS = true;
		accelS += .02;
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)){
		keepMovingW = true;
		accelW += .02;
	}
	//if two opposing keys are pressed then make them false
	if (keepMovingA && keepMovingD)
	{
		keepMovingA = false;
		keepMovingD = false;
	}
	if (keepMovingW && keepMovingS)
	{
		keepMovingW = false;
		keepMovingS = false;
	}
	if (keepMovingA && keepMovingD && keepMovingW && keepMovingS) // feel like it doesn't work bc of D
	{
		keepMovingW = false;
		keepMovingS = false;
		keepMovingA = false;
		keepMovingD = false;
	}
	//set the max speed
	if (accelA >= maxSpeed || accelD == maxSpeed || accelW == maxSpeed)
		accelA = maxSpeed;
	if (accelS >= maxSpeed)
		accelS = maxSpeed;
	if (accelD >= maxSpeed)
		accelD = maxSpeed;
	if (accelW >= maxSpeed)
		accelW = maxSpeed;

}

void movementKeyReleased(){
	//if an opposing key is lifted but the other is not then it will continue to move in the pressed direction instead of stopping still
	if (!sf::Keyboard::isKeyPressed(sf::Keyboard::D)){
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
			keepMovingA = true;
		keepMovingD = false;
		accelD = 0;
	}
	if (!sf::Keyboard::isKeyPressed(sf::Keyboard::A)){
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
			keepMovingD = true;
		keepMovingA = false;
		accelA = 0;
	}
	if (!sf::Keyboard::isKeyPressed(sf::Keyboard::S)){
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
			keepMovingW = true;
		keepMovingS = false;
		accelS = 0;
	}
	if (!sf::Keyboard::isKeyPressed(sf::Keyboard::W)){
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
			keepMovingS = true;
		keepMovingW = false;
		accelW = 0;
	}
}
/*
This part needs much improvement.

****NOTE: All of these changes should be done in this one file. You shouldn't need to change anything outside of this.
If you need to edit code in another file make a note of what you changed so we can sync it all.
Also don't post any of your changes until we get back, you both will be taking different paths so we don't want
anything conflicting, we will resolve all differences when we get back.****

If you are pressed against a wall and hold diagonal,
you should move in the direction that you still can move. With this, you get stuck.
	Solution: If it hits vertical wall then it only moves by playerY
			  If it hits horiztonal wall then it only moves by playerX
			  else it moves diagonally with playerX and playerY

Also, we should have some acceleration to Susan's movement not much but just so that
she is more slimelike instead of like a sliding brick.
	Solution: Acceleration variables as global variables
				within keyPressed - increased the acceleration by .05 until it reaches a max speed which will make it stay at max speed
				within keyRelease - make that accel = 0
	**Made 4 accel variables because I tried one variable and the opposing keys made inaccurate movements because it's shared so
	it went slowly went to one end

Also we need to make the movement in a for loop to move in one pixel increments.
The way this is currently coded the player tries to move a set distance, if it will hit a wall,
it won't move at all. In reality, it should move micro steps until it is pressed up against the wall.
Ex: This system, if you are 5px from a wall and try to move, it will check 6px away.
Since you will hit the wall with 6px, you won't move at all. What should happen is that Susan
moves 1px and then checks again 1px infront of her. And keep doing that for 6 times. If any of those
hit the wall then it breaks out of the for loop.
Don't use the for loop method if the 6px per frame movement wouldn't hit a wall. Because it is much
less efficient to check wall collision 6 times per frame instead of 1.
	Solution: Make a for loop for each key if statements -
	check 6 pixels ahead for one key pressed 
	if statement inside for loop will break to stop for loop if hit a wall and ends the for loop
	else move according to the key statement by 1 pixel
	Tried to make the playercollision within the for loop in the 2nd condition, but gave weird bugs such as teleporting through wall
		Ex: for (int x = 1; x <= 6 || playerCollision(playerX, playerY - 6); x++) - teleports

Also this code actually executes if the player is pressing two opposing directions at the same time.
Even though the player doesn't visually move (which is correct), the code is still being run when it isn't necessary.
Remember, even though computers are fast, we want to keep the unnecessary calcuations to a minimum.
And even though I bundled the collision into a neat function, it is still doing hundreds of checks each time it is called.
	Solution: Solved by putting an if condition if the two opposing directions are true in movementKeyPressed then both of them are false

Also if the player holds down 3 keys, the one key that is not in conflict (aka A&D conflict but W does not)
makes the player move faster than they should. So by holding extra keys the player moves too fast.
I'm not going to tell you the cause for this, try and figure this one out yourself and fix it.
Problem: The player X or Y are added to the diagonal for example, A and D will oppose to nullify but W will add onto
W && D and W && A therefore it will double the speed for the non-opposing direction
	Solution: Solved by putting an if condition if the two opposing directions are true in movementKeyPressed then both of them are false

Also the playerCollision function takes integers as arguments. Currently these doubles are just being truncated which
will inaccurately estimate the players position, round the values before passing them into playerCollision.
	Solution: if the number's fractional part is 0.5 or greater, the integer part has been incremented before the truncation. 
			  And if it was less than 0.5, then it will just get trunctated without affecting the integer part.

Also, a thought experiment for you. When Susan is facing up, why does her body touch the wall on the left side,
but on the other 3 sides there is a larger gap between her and the wall. Don't do any coding to solve this. Just try to figure it out
and write me an explanation. This is a good test in debugging.
	one theory is the drawing
	inaccurate coding by the level stimulator?

problem : trying to suddenly switch back opposite sides but stops completely
Problem: the new false statements for opposing keys stops it
Ex: keep holding D then click A while holding D will stop Susan
Tried to put movementKeyRelease in each for loop and then another condition if !moving(KEY) then break to stop the for loop
	Solution: Check in movementkeyRelease if that if one key is not pressed but the other is still
			  then it will continue that key instead of keeping it false

problem: holding WS then pressing D will not move but pressing A instead of D will make it move
problem: when a diagonal is pressed then the opposing diagonal is pressed, Susan will keep moving toward the first diagonal
		 Probably because the problem with D doesn't work affects this problem too
*/

