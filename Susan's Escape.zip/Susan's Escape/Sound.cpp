#include "Sound.hpp"

std::map<std::string, std::unique_ptr<sf::Music>> sounds;

void loadSound(std::string name, std::string fileName)
{
	sounds.insert(std::make_pair(name, std::unique_ptr<sf::Music>(new sf::Music())));
	sounds[name]->openFromFile(fileName);
}

bool playSound(std::string name, bool forced){
	if (sounds[name]->getStatus() == sf::SoundSource::Status::Playing && !forced)
		return false;
	sounds[name]->play();
	return true;
}

void stopSound(std::string name){
	if (sounds[name]->getStatus() == sf::SoundSource::Status::Playing)
		sounds[name]->stop();
}

void pauseSound(std::string name){
	sounds[name]->pause();
}

void setLoop(std::string name, bool toggle){
	sounds[name]->setLoop(toggle);
}

void setPitch(std::string name, double pitch){
	if (pitch == 0)
		pitch = 1;
	sounds[name]->setPitch(pitch);
}