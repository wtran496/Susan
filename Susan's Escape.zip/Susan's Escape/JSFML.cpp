#include "JSFML.hpp"

bool closing = false;
sf::RenderWindow window(sf::VideoMode(DISPLAY_WIDTH, DISPLAY_HEIGHT), WINDOW_NAME, sf::Style::Close);


void setIcon(std::string path){
	sf::Image icon;
	icon.loadFromFile(path);
	window.setIcon(icon.getSize().x, icon.getSize().y, icon.getPixelsPtr());
}


//Rect Colors
sf::Color rectC(0, 0, 0, 255);

void background(int r, int g, int b, int a){
	sf::Vector2f backgroundSize(DISPLAY_WIDTH, DISPLAY_HEIGHT);
	sf::Color backgroundColor(r, g, b, a);
	sf::RectangleShape background(backgroundSize);
	background.setOrigin(DISPLAY_WIDTH/2, DISPLAY_HEIGHT/2);
	background.setPosition(DISPLAY_WIDTH/2, DISPLAY_HEIGHT/2);
	background.setFillColor(backgroundColor);
	window.draw(background);
}

void background(int grey, int a){
	sf::Vector2f backgroundSize(DISPLAY_WIDTH, DISPLAY_HEIGHT);
	sf::Color backgroundColor(grey, grey, grey, a);
	sf::RectangleShape background(backgroundSize);
	background.setOrigin(DISPLAY_WIDTH/2, DISPLAY_HEIGHT/2);
	background.setPosition(DISPLAY_WIDTH/2, DISPLAY_HEIGHT/2);
	background.setFillColor(backgroundColor);
	window.draw(background);
}

void rectColor(int r, int g, int b, int a){
	sf::Color c(r, g, b, a);
	rectC = c;
}

void rect(int x, int y, int xSize, int ySize){
	sf::Vector2f rectSize(xSize, ySize);
	sf::RectangleShape rect(rectSize);
	rect.setOrigin(xSize/2, ySize/2);
	rect.setPosition(x, y);
	rect.setFillColor(rectC);
	window.draw(rect);
}

void rectOutline(int x, int y, int xSize, int ySize){
	int addLength = 5;
	rect(x, y-ySize/2-1, xSize, 3); //Top
	rect(x, y+ySize/2+1, xSize, 3); //Bottom
	rect(x-xSize/2-1, y, 3, ySize+addLength); //Left
	rect(x+xSize/2+1, y, 3, ySize+addLength); //Right
}

box::box(){}

box::box(int a, int b, float c, float d){
	xPos = a;
	yPos = b;
	xSize = c;
	ySize = d;
}

void rectOutline(box b){
	int addLength = 5;
	rect(b.xPos, b.yPos-b.ySize/2-1, b.xSize, 3); //Top
	rect(b.xPos, b.yPos+b.ySize/2+1, b.xSize, 3); //Bottom
	rect(b.xPos-b.xSize/2-1, b.yPos, 3, b.ySize+addLength); //Left
	rect(b.xPos+b.xSize/2+1, b.yPos, 3, b.ySize+addLength); //Right
}

void rect(box b){
	sf::Vector2f rectSize(b.xSize, b.ySize);
	sf::RectangleShape rect(rectSize);
	rect.setOrigin(b.xSize/2, b.ySize/2);
	rect.setPosition(b.xPos, b.yPos);
	rect.setFillColor(rectC);
	window.draw(rect);
}

int distance(int x1, int y1, int x2, int y2){
	return int(sqrt(pow(x1-x2, 2)+pow(y1-y2, 2)));
}



int keyCode = 0;

mouseVariables mouse;

mouseVariables::mouseVariables(){
	left = false;
	right = false;
	x = 0;
	y = 0;
	down = false;
	outside = false;
}

void mouseVariables::printLocation(){
	if (outside)
		println("Mouse Outside");
	else
		println("Mouse: "+std::to_string(x)+"\t"+std::to_string(y));
}

void mousePressedHandler(){
	while (window.isOpen())
	{
		if (closing)
			return;
		if (window.hasFocus())
		{
			sf::Vector2i position(sf::Mouse::getPosition(window));
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
				mouse.left = true;
			else
				mouse.left = false;
			if (sf::Mouse::isButtonPressed(sf::Mouse::Right))
				mouse.right = true;
			else
				mouse.right = false;
			if (mouse.left || mouse.right)
			{
				if (mouse.left)
				{
					if (!mouse.down && !mouse.outside)
					{
						//mouse.printLocation();
						clickHandler();
					}
				}
				mouse.down = true;
			}
			else
				mouse.down = false;
			if ((mouse.x != position.x || mouse.y != position.y))
			{
				if (position.x < DISPLAY_WIDTH && position.x > 0 && position.y < DISPLAY_HEIGHT && position.y > 0)
				{
					mouse.x = position.x;
					mouse.y = position.y;
					mouse.outside = false;
				}
				else
					mouse.outside = true;
			}
		}
		std::this_thread::sleep_for(std::chrono::milliseconds(50));
	}
}

bool mouseover(box b){
	sf::FloatRect r(b.xPos-b.xSize/2, b.yPos-b.ySize/2, b.xSize, b.ySize);
	if (r.contains(mouse.x, mouse.y) && !mouse.outside)
		return true;
	return false;
}


sf::Font defaultFont;

textDisplay::textDisplay(std::string text){
	displayText.setString(text);
	displayText.setFont(defaultFont);
	textAlign = 1;
}
void textDisplay::setText(std::string text){
	displayText.setString(text);
}
void textDisplay::setColor(int r, int g, int b, int a){
	sf::Color color;
	color.r = r;
	color.g = g;
	color.b = b;
	color.a = a;
	displayText.setFillColor(color);
}
void textDisplay::setColor(int grey, int a){
	sf::Color color;
	color.r = grey;
	color.g = grey;
	color.b = grey;
	color.a = a;
	displayText.setFillColor(color);
}
void textDisplay::setSize(int size){
	displayText.setCharacterSize(size);
}
void textDisplay::setFont(sf::Font &font){
	displayText.setFont(font);
}
int textDisplay::getTextWidth(){
	return displayText.getLocalBounds().width;
}
void textDisplay::align(int alignment = 1){
	if (alignment >= 1 && alignment <= 3)
		textAlign = alignment;
	else
		textAlign = 1;
}
void textDisplay::draw(int x, int y){
	int width = displayText.getLocalBounds().width;
	if (textAlign == 2) //LEFT
		displayText.setOrigin(0, 0);
	else if (textAlign == 3) //RIGHT
		displayText.setOrigin((width % 2 == 1 ? width+1 : width), 0);
	else //CENTER
		displayText.setOrigin((width/2 % 2 == 1 ? width/2+1 : width/2), 0);
	displayText.setPosition(x, y);
	window.draw(displayText);
}


std::map<std::string, std::unique_ptr<Image>> images;
std::map<std::string, std::unique_ptr<sf::Texture>> textures;

Image::Image(std::unique_ptr<sf::Texture> const &texture)
{
	(*texture).setSmooth(true);
	image.setTexture(*texture);
	image.setOrigin(image.getLocalBounds().width/2, image.getLocalBounds().height/2);
}
void Image::tint(int r, int g, int b)
{
	imageTint.r = r;
	imageTint.g = g;
	imageTint.b = b;
	image.setColor(imageTint);
}
void Image::tint(int r, int g, int b, int a)
{
	imageTint.r = r;
	imageTint.g = g;
	imageTint.b = b;
	imageTint.a = a;
	image.setColor(imageTint);
}
void Image::tint(int grey)
{
	imageTint.r = grey;
	imageTint.g = grey;
	imageTint.b = grey;
	image.setColor(imageTint);
}
void Image::tint(int grey, int a)
{
	imageTint.r = grey;
	imageTint.g = grey;
	imageTint.b = grey;
	imageTint.a = a;
	image.setColor(imageTint);
}
void Image::setScale(double ratio){
	image.setScale(ratio, ratio);
}
void Image::setRotation(double angle){
	image.setRotation(angle);
}
void Image::draw(double x, double y){
	image.setPosition(x, y);
	window.draw(image);
}

void loadSprite(std::string name, std::string imageName){
	images.insert(std::make_pair(name, std::unique_ptr<Image>(new Image(textures[imageName]))));
}

void loadTexture(std::string name, std::string path){
	textures.insert(std::make_pair(name, std::unique_ptr<sf::Texture>(new sf::Texture())));
	textures[name]->loadFromFile(path);
}

void loadImage(std::string name, std::string path){
	loadTexture(name, path);
	loadSprite(name, name);
}

//Higher level image functions

void tint(std::string name, int r, int g, int b){
	images[name]->tint(r, g, b);
}

void tint(std::string name, int r, int g, int b, int a){
	images[name]->tint(r, g, b, a);
}

void tint(std::string name, int grey){
	images[name]->tint(grey);
}

void tint(std::string name, int grey, int a){
	images[name]->tint(grey, a);
}

void setScale(std::string name, double ratio){
	images[name]->setScale(ratio);
}

void setRotation(std::string name, double angle){
	images[name]->setRotation(angle);
}

void draw(std::string name, double x, double y){
	images[name]->draw(x, y);
}

sf::Clock c;

int getTime(){
	return c.getElapsedTime().asMilliseconds();
}

std::default_random_engine generator(time(NULL));

int random(int min, int max){
	std::uniform_int_distribution<int> distribution(min, max);
	return distribution(generator);
}

int random(int max){
	std::uniform_int_distribution<int> distribution(0, max);
	return distribution(generator);
}